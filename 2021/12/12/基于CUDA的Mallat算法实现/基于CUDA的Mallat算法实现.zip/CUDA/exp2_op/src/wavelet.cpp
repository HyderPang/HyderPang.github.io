#include <time.h>
#include <iostream>

#include "cuda.h"
#include "cuda_runtime.h"

#include "wavelet.h"
#include "myblas.cuh"

using namespace cv;
/*-------------------------------------------------------------------------------
* Function: dwt2
* Descreiption: Desecrate wavelet transform
* Input:
    -src: source image.
    -h_l: low-pass decomposing filter coefficients
    -h_h: high-pass decomposing filter coefficients
* Output:
    |A|H|
    |V|D|
* Return:
    None
--------------------------------------------------------------------------------*/
Mat dwt2(const Mat & _src, const Mat & _h_l, const Mat & _h_h){
    assert(_h_l.rows == 1 && _h_h.rows == 1);
    assert(_src.cols >= _h_l.cols && _src.cols >= _h_h.cols);

    clock_t t = clock();
    
    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    //Conv each row.
    Mat _dl = Mat::zeros(M, N, src.type());
    Mat _dh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < M; i++) {
        filter2D(src.row(i), _dl.row(i), -1, h_l);
        filter2D(src.row(i), _dh.row(i), -1, h_h);
    }
    //down sampling by cols.
    //splice by cols.
    Mat d = Mat::zeros(M, N, src.type());
    for (int i = 0; i < N / 2; i++){
        _dl.col(i*2).copyTo(d.col(i));
        _dh.col(i*2).copyTo(d.col(i + N / 2));
    }

    //Conv each col.
    _dl = Mat::zeros(M, N, src.type());
    _dh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < N; i++) {
        filter2D(d.col(i), _dl.col(i), -1, h_l.t());
        filter2D(d.col(i), _dh.col(i), -1, h_h.t());
    }
    //down sampling by rows.
    //splice by rows
    for (int i = 0; i < M / 2; i++) {
        _dl.row(i*2).copyTo(d.row(i));
        _dh.row(i*2).copyTo(d.row(i + N / 2));
    }

    t = clock() - t;
    printf("dwt %dms\n", t);

    return d;
}
/*-------------------------------------------------------------------------------
* Function: idwt2
* Descreiption: Inverse-desecrate wavelet transform
* Input:
    -src: source image.
        |LL|HL| ~ |A|H|
        |LH|HH|   |V|D|
    -h_l: low-pass reconstructive filter coefficients
    -h_h: high-pass reconstructive filter coefficients
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat idwt2(const Mat & _src, const Mat & _h_l, const Mat & _h_h){
    assert(_h_l.rows == 1 && _h_h.rows == 1);
    assert(_src.cols >= _h_l.cols && _src.cols >= _h_h.cols);

    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    clock_t t = clock();

    //up sampling by rows.
    Mat _rl = Mat::zeros(M, N, src.type());
    Mat _rh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < M / 2; i++) {
        src.row(i).copyTo(_rl.row(i * 2));
        src.row(i + M / 2).copyTo(_rh.row(i * 2));
    }
    
    //Conv each cols.
    Mat rl = Mat::zeros(M, N, src.type());
    Mat rh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < N; i++) {
        filter2D(_rl.col(i), rl.col(i), -1, h_l.t());
        filter2D(_rh.col(i), rh.col(i), -1, h_h.t());
    }
    //Add
    Mat r = rl + rh;

    //up sampling by cols.
    _rl = Mat::zeros(M, N, src.type());
    _rh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < N / 2; i++) {
        r.col(i).copyTo(_rl.col(i * 2));
        r.col(i + N / 2).copyTo(_rh.col(i * 2));
    }
    //Conv each rows.
    rl = Mat::zeros(M, N, src.type());
    rh = Mat::zeros(M, N, src.type());
    for (int i = 0; i < M; i++) {
        filter2D(_rl.row(i), rl.row(i), -1, h_l);
        filter2D(_rh.row(i), rh.row(i), -1, h_h);
    }
    //Add
    r = rl + rh;

    t = clock() - t;
    printf("dwt %dms\n", t);
   
    return r;
}

/*-------------------------------------------------------------------------------
* Function: wavedec2
* Descreiption: multi-level wavelet decomposing.
* Input:
    -src: source image.
    -h_l: low-pass decomposing filter coefficients
    -h_h: high-pass decomposing filter coefficients
    -level: decomposing level.
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat wavedec2(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level) {
    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    Mat dst = src.clone();
    int div = 1;
    for (int i = 0; i < level; i++) {
        Rect aoi = Rect(0, 0, M / div, N / div);
        Mat tmp = dwt2(dst(aoi), h_l, h_h);
        tmp.copyTo(dst(aoi));
        div *= 2;
    }

    return dst;
}

/*-------------------------------------------------------------------------------
* Function: waverec2
* Descreiption: multi-level wavelet reconstruction.
* Input:
    -src: source image(Wavelet coefficients).
    -h_l: low-pass reconstructing filter coefficients
    -h_h: high-pass reconstructing filter coefficients
    -level: decomposing level.
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat waverec2(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level) {
    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    Mat dst = src.clone();
    int div = 1;
    for (int i = 0; i < level-1; i++) {
        div *= 2;
    }

    for (int i = 0; i < level; i++) {
        Rect aoi = Rect(0, 0, M / div, N / div);
        Mat tmp = idwt2(dst(aoi), h_l, h_h);
        tmp.copyTo(dst(aoi));
        div /= 2;
    }

    return dst;
}

Mat thresh_Coef(Mat & src, int Thresh, int level) {
    Mat &img = Mat_<uchar>(src);
    int div = 1;
    for (int i = 0; i < level; i++) {
        div *= 2;
    }
    int m = img.rows / div;
    int n = img.cols / div;
    for (int i = 0; i < img.rows; i++) {
        for (int j = 0; j < img.cols; j++) {
            if (img.at<uchar>(i, j) < Thresh && (i >= m || j >= n)) {
                img.at<uchar>(i, j) = 0;
            }
        }
    }

    return img;
}


/*-------------------------------------------------------------------------------
* Function: dwt2_gpu
* Descreiption: Desecrate wavelet transform using GPU.
* Input:
    -src: source image.
    -h_l: low-pass decomposing filter coefficients
    -h_h: high-pass decomposing filter coefficients
* Output:
    |A|H|
    |V|D|
* Return:
    None
--------------------------------------------------------------------------------*/
Mat dwt2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h) {
    assert(_h_l.rows == 1 && _h_h.rows == 1);
    assert(_src.cols >= _h_l.cols && _src.cols >= _h_h.cols);

    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    Mat dst = src.clone();
    int M = src.rows;
    int N = src.cols;
    int Kernel_len = h_l.cols;
    int imsize_b = M * N * sizeof(float);
    int kernelsize_b = Kernel_len * sizeof(float);
    
    //convert Mat to interface array.
    float* pimg = (float*)malloc(imsize_b);
    float* pdst = (float*)malloc(imsize_b);
    memset(pdst, 0, imsize_b);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            pimg[i*N + j] = src.at<float>(i, j);
        }
    }
    // I will use stream here in the future!!!!!
    float* pkernel_l = (float*)malloc(kernelsize_b);
    float* pkernel_h = (float*)malloc(kernelsize_b);
    for (int i = 0; i < Kernel_len; i++) {
        pkernel_l[i] = h_l.at<float>(i);
        pkernel_h[i] = h_h.at<float>(i); 
    }

    //call kernel-wrapper function.
    clock_t t = clock();
    dwt_gpu_wrapper(pimg, pdst, pkernel_l, pkernel_h, M, N, Kernel_len);
    t = clock() - t;
    printf("DWT-GPU: %dms\n", t);

    //convert array to Mat.
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            dst.at<float>(i, j) = pdst[i*N + j];
        }
    }

    //free psrc.
    free(pimg);
    free(pdst);
    free(pkernel_l);
    free(pkernel_h);

    return dst;
}

/*-------------------------------------------------------------------------------
* Function: idwt2_gpu
* Descreiption: Inverse-desecrate wavelet transform using GPU.
* Input:
    -src: source image.
        |LL|HL| ~ |A|H|
        |LH|HH|   |V|D|
    -h_l: low-pass reconstructive filter coefficients
    -h_h: high-pass reconstructive filter coefficients
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat idwt2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h) {
    assert(_h_l.rows == 1 && _h_h.rows == 1);
    assert(_src.cols >= _h_l.cols && _src.cols >= _h_h.cols);

    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    Mat dst = src.clone();
    int M = src.rows;
    int N = src.cols;
    int Kernel_len = h_l.cols;
    int imsize_b = M * N * sizeof(float);
    int kernelsize_b = Kernel_len * sizeof(float);

    int USE_THREADS_PER_BLOCK = 128;

    //convert Mat to interface array.
    float* pimg = (float*)malloc(imsize_b);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            pimg[i*N + j] = src.at<float>(i, j);
        }
    }
    // I will use stream here in the future!!!!!
    float* pkernel_l = (float*)malloc(kernelsize_b);
    float* pkernel_h = (float*)malloc(kernelsize_b);
    for (int i = 0; i < Kernel_len; i++) {
        pkernel_l[i] = h_l.at<float>(i);
        pkernel_h[i] = h_h.at<float>(i);
    }

    //call kernel-wrapper function.
    clock_t t = clock();
    idwt_gpu_wrapper(pimg, pimg, pkernel_l, pkernel_h, M, N, Kernel_len);
    t = clock() - t;
    printf("IDWT-GPU: %dms\n", t);

    //convert array to Mat.
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            dst.at<float>(i, j) = pimg[i*N + j];
        }
    }

    //free psrc.
    free(pimg);
    free(pkernel_l);
    free(pkernel_h);

    return dst;
}

/*-------------------------------------------------------------------------------
* Function: wavedec2_gpu
* Descreiption: multi-level wavelet decomposing using GPU.
* Input:
    -src: source image.
    -h_l: low-pass decomposing filter coefficients
    -h_h: high-pass decomposing filter coefficients
    -level: decomposing level.
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat wavedec2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level) {
    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    Mat dst = src.clone();
    int div = 1;
    for (int i = 0; i < level; i++) {
        clock_t t = clock();

        Rect aoi = Rect(0, 0, M / div, N / div);
        Mat tmp = dwt2_gpu(dst(aoi), h_l, h_h);
        tmp.copyTo(dst(aoi));
        div *= 2;

        t = clock() - t;
        printf("DWT-GPU-full: %dms\n", t);
    }

    return dst;
}

/*-------------------------------------------------------------------------------
* Function: waverec2_gpu
* Descreiption: multi-level wavelet reconstruction using GPU.
* Input:
    -src: source image(Wavelet coefficients).
    -h_l: low-pass reconstructing filter coefficients
    -h_h: high-pass reconstructing filter coefficients
    -level: decomposing level.
* Return:
    Recovered image.
--------------------------------------------------------------------------------*/
Mat waverec2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level) {
    Mat &src = Mat_<float>(_src);
    Mat &h_l = Mat_<float>(_h_l);
    Mat &h_h = Mat_<float>(_h_h);
    int M = src.rows;
    int N = src.cols;

    Mat dst = src.clone();
    int div = 1;
    for (int i = 0; i < level - 1; i++) {
        div *= 2;
    }

    for (int i = 0; i < level; i++) {
        clock_t t = clock();

        Rect aoi = Rect(0, 0, M / div, N / div);
        Mat tmp = idwt2_gpu(dst(aoi), h_l, h_h);
        tmp.copyTo(dst(aoi));
        div /= 2;

        t = clock() - t;
        printf("IDWT-GPU-full: %dms\n", t);
    }

    return dst;
}
