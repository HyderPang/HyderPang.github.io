#include <iostream>
#include <math.h>
#include <time.h>
//opencv
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
//my wavelet
#include "wavelet.h"
#include "myblas.cuh"

using namespace cv;
using namespace std;

Mat addNoise_2_im(Mat & src, float SNR = 80);


int main(int argc, char** argv) { 
    Mat img = imread("LENA.BMP", 1);
    cvtColor(img, img, COLOR_BGR2GRAY);

    if (img.empty()) {
        cout << "empty " << endl;
        return 0;
    }  
    //cout << "Using GPU-" << cuda::getDevice() << endl;

    //Wavelet function 
    int wavelet_len = 6;
    float d_l_array[] = { 0.03522629188570953, -0.08544127388202666, -0.13501102001025458, 0.45987750211849154, 0.8068915093110925, 0.33267055295008263 };
    float d_h_array[] = {-0.33267055295008263, 0.8068915093110925, -0.45987750211849154, -0.13501102001025458, 0.08544127388202666, 0.03522629188570953 };
    float r_l_array[] = { 0.33267055295008263, 0.8068915093110925, 0.45987750211849154, -0.13501102001025458, -0.08544127388202666, 0.03522629188570953 };
    float r_h_array[] = { 0.03522629188570953, 0.08544127388202666, -0.13501102001025458, -0.45987750211849154, 0.8068915093110925, -0.33267055295008263 };

    Mat l_d(1, wavelet_len, CV_32F, d_l_array);
    Mat h_d(1, wavelet_len, CV_32F, d_h_array);
    Mat l_r(1, wavelet_len, CV_32F, r_l_array);
    Mat h_r(1, wavelet_len, CV_32F, r_h_array);
    float rate = 1 ;
    l_d = l_d * rate;
    h_d = h_d * rate;
    l_r = l_r * rate;
    h_r = h_r * rate;

    print_GPU_prop();
    
    //add Noise
    img = addNoise_2_im(img, 50);

    //wavelet decomposing and reconstruct.
    int level = 1;
    Mat dec_tree = wavedec2(img, l_d, h_d, level);
    Mat recovered_img = waverec2(dec_tree, l_r, h_r, level);
    //GPU version.
    Mat dec_tree_gpu = wavedec2_gpu(img, l_d, h_d, level);
    Mat recovered_img_gpu = waverec2_gpu(dec_tree_gpu, l_r, h_r, level);
    
    //Display
    Mat temp = img.clone();
    convertScaleAbs(temp, temp, 1);
    imshow("original", temp);

    temp = dec_tree_gpu.clone();
    convertScaleAbs(temp, temp, 1);
    imshow("dec tree-GPU", temp);

    temp = recovered_img_gpu.clone();
    convertScaleAbs(temp, temp, 1);
    imshow("recovered-GPU", temp);

    temp = dec_tree.clone();
    convertScaleAbs(temp, temp, 1);
    imshow("dec tree-CPU", temp);

    temp = recovered_img.clone();
    convertScaleAbs(temp, temp, 1);
    imshow("recovered-CPU", temp);

    waitKey(0);

    int rad_step = 256;
    int rad = rad_step;
    int test_img_num = 10;
    int *ts_cpu, *ts_gpu;
    ts_cpu = new int [test_img_num];
    ts_gpu = new int [test_img_num];
    for (int i = 0; i < test_img_num; i++) {
        printf("\n================running test %d x %d========================\n", rad, rad);
        printf("Wavelet function length : %d\n", wavelet_len);
        printf("Wavelet decomposing level: %d\n", level);

        resize(img, img, Size(rad, rad));

        //run test - CPU
        /*
        printf("Running on CPU\n");
        clock_t t = clock();
        Mat cpu_dec_tree = wavedec2(img, l_d, h_d, level);
        Mat cpu_recovered_img = waverec2(cpu_dec_tree, l_r, h_r, level);
        t = clock() - t;
        printf("-------->CPU runtime: %dms\n", t);
        ts_cpu[i] = t;
        */

        //run test - GPU
        printf("Running on GPU\n");
        clock_t t_gpu = clock();
        Mat gpu_dec_tree = wavedec2_gpu(img, l_d, h_d, level);
        Mat gpu_recovered_img = waverec2_gpu(gpu_dec_tree, l_r, h_r, level);
        t_gpu = clock() - t_gpu;
        printf("-------->GPU runtime: %dms\n", t_gpu);
        ts_gpu[i] = t_gpu;

        rad += rad_step;
    }
    
    return 0;
}

Mat addNoise_2_im(Mat & src, float SNR) {
    Mat &img = Mat_<uchar>(src);
    Mat noise = Mat::zeros(img.rows, img.cols, img.type());
    RNG rng;
    float sigma = pow(255 / (pow(10, SNR / 20)), 2);
    rng.fill(noise, RNG::NORMAL, 0, sigma);

    img = img + noise;

    return img;
}

