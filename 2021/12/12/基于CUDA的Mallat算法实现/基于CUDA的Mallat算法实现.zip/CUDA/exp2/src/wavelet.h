#ifndef __WAVELET_CUH
#define __WAVELET_CUH

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>  

using namespace cv;

Mat dwt2(const Mat & _src, const Mat & _h_l, const Mat & _h_h);
Mat idwt2(const Mat & _src, const Mat & _h_l, const Mat & _h_h);
Mat wavedec2(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level);
Mat waverec2(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level);
Mat thresh_Coef(Mat & src, int Thresh, int level);

Mat dwt2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h);
Mat idwt2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h);
Mat wavedec2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level);
Mat waverec2_gpu(const Mat & _src, const Mat & _h_l, const Mat & _h_h, int level);

#endif
