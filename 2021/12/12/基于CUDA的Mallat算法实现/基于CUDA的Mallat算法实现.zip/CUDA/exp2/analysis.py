import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt


def rightness(rads, rows=5, filepath = 'output\\'):
    num = len(rads)
    figures = int(np.ceil(num*1.0)/rows)
    img_cnt = 0
    for i in range(figures):
        for j in range(rows):
            # read img
            rad = rads[img_cnt]
            img_name = filepath + 'img %dx%d.bmp' % (rad, rad)
            CPU_REC_name = filepath + 'CPU rec %dx%d.bmp' % (rad, rad)
            GPU_REC_name = filepath + 'GPU rec %dx%d.bmp' % (rad, rad)
            img = cv.imread(img_name)
            img_cpu = cv.imread(CPU_REC_name)
            img_gpu = cv.imread(GPU_REC_name)
            img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
            img_cpu = cv.cvtColor(img_cpu, cv.COLOR_BGR2GRAY)
            img_gpu = cv.cvtColor(img_gpu, cv.COLOR_BGR2GRAY)
            # residual
            img_n = img / np.max(img)
            img_cpu_n = img_cpu / np.max(img_cpu)
            img_gpu_n = img_gpu / np.max(img_gpu)
            img_cpu_r = abs(img_cpu_n - img_n)
            img_gpu_r = abs(img_gpu_n - img_n)
            MSE_cpu = np.sum(img_cpu_r ** 2) / img_cpu_r.size
            MSE_gpu = np.sum(img_gpu_r ** 2) / img_gpu_r.size
            PSNR_cpu = 10*np.log10(255*255/(MSE_cpu + 1e-9))
            PSNR_gpu = 10*np.log10(255*255/(MSE_gpu + 1e-9))
            # Plot
            # 1.raw image
            plt.subplot(rows, 5, j*5+1)
            plt.imshow(img, cmap ='gray')
            plt.xticks([])
            plt.yticks([])
            plt.title('(%d)' % (rad), verticalalignment='center')
            # 2.CPU
            plt.subplot(rows, 5, j * 5 + 2)
            plt.imshow(img_cpu, cmap ='gray')
            plt.xticks([])
            plt.yticks([])
            if j == 0:
                plt.title('Recovered by CPU', verticalalignment='center', )
            # 3.GPU
            plt.subplot(rows, 5, j * 5 + 3)
            plt.imshow(img_gpu, cmap ='gray')
            plt.xticks([])
            plt.yticks([])
            if j == 0:
                plt.title('Recovered by GPU', verticalalignment='center', )
            # 4.CPU Residual
            plt.subplot(rows, 5, j * 5 + 4)
            plt.imshow(img_cpu_r, cmap='plasma')
            plt.xticks([])
            plt.yticks([])
            plt.text(0, rad, 'MSE=%.3f' % MSE_cpu, color='w')
            if MSE_cpu:
                plt.text(0, rad * 7 / 8, 'PSNR=%.3fdB' % PSNR_cpu, color='w')
            if j == 0:
                plt.title('Residual of CPU', verticalalignment='center', )
            # 5.GPU Residual
            plt.subplot(rows, 5, j * 5 + 5)
            plt.imshow(img_gpu_r, cmap='plasma')
            plt.xticks([])
            plt.yticks([])
            plt.text(0, rad, 'MSE=%.3f' % MSE_gpu, color='w')
            if MSE_gpu:
                plt.text(0, rad * 7 / 8, 'PSNR=%.3fdB' % PSNR_gpu, color='w')
            if j == 0:
                plt.title('Residual of GPU', verticalalignment='center', )
            img_cnt += + 1
            if img_cnt > num:
                break
        plt.show()

def acc_ratio(rad, cpu, gpu):
    acc_ratio = np.array(cpu) / np.array(gpu)
    bar_w = np.abs((rad[1] - rad[0]) * 0.3)
    # twin x
    fig = plt.figure()
    ax1 = fig.subplots()
    ax2 = ax1.twinx()
    # ax1 - runtime
    bar_xl = rad-bar_w//2
    bar_xr = rad+bar_w//2
    ax1.bar(bar_xl, gpu, width=bar_w, label='GPU')
    ax1.bar(bar_xr, cpu, width=bar_w, label='CPU')
    ax1.set_xticks(rad)
    ax1.set_xlabel('Image radius / pixels')
    ax1.set_ylabel('Runtime / ms')
    ax1.legend()
    # ax2 - acc ratio
    ax2.plot(rad, acc_ratio, marker='.')
    ax2.set_ylabel('Speedup')
    for x, y in zip(rad, acc_ratio):
        ax2.text(x, y, '%.1f' % y)

    plt.show()


def compare(rad, naive, opt):
    bar_w = np.abs((rad[1] - rad[0]) * 0.3)
    bar_xl = rad-bar_w//2
    bar_xr = rad+bar_w//2
    plt.bar(bar_xl, naive, width=bar_w, label='Naive')
    plt.bar(bar_xr, opt, width=bar_w, label='Optimized')
    plt.xticks(rad)
    plt.xlabel('Image radius / pixels')
    plt.ylabel('Runtime / ms')
    plt.legend()

    plt.show()

rad = [128, 256, 384, 512, 640, 768, 896, 1024, 1152, 1280,]
cpu_runtime = [83, 254, 503, 905, 1466, 1907, 2520,3334, 4113, 4808]
gpu_runtime = [7, 20, 41, 68, 100, 135, 162, 224, 286, 376,]
gpu_opt_runtime = [9, 20, 42, 65, 97, 130, 161, 207, 270, 330,]
gpu_dwt = [2, 3, 4, 5, 6, 7]
gpu_dwt_full = [4, 10, 18, 32, 46, 65, 75, 104, 126, 169, ]
gpu_op_dwt = [2, 3, 3, 5, 7, 8]
gpu_op_dwt_full = [3, 10, 18, 31, 46, 64, 77, 101, 115, 145]

# rightness([128, 256, 512, 896, 1024, 1280], rows=3)
# acc_ratio(rad, cpu_runtime, gpu_opt_runtime)
compare(rad, gpu_dwt_full, gpu_op_dwt_full)