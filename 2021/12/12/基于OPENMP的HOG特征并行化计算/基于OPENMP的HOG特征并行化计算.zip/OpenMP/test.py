import ctypes
import numpy as np
import time
import sys
import cv2 as cv


class work:
    def __init__(self, dll_name = './/hog.dll'):
        self.dll = ctypes.CDLL(dll_name)

        _doublepp = np.ctypeslib.ndpointer(dtype=np.uintp, ndim=1, flags='C')

        self._conv2 = self.dll.conv2
        self._conv2.argtypes = [_doublepp, _doublepp, _doublepp, ctypes.c_int, ctypes.c_int, ctypes.c_int]

        self._hog = self.dll.HOG
        self._hog.argtypes = [_doublepp, _doublepp, _doublepp, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,]

    def conv2(self, x, kernel):
        y = np.zeros_like(x)
        xpp = (x.__array_interface__['data'][0]
        + np.arange(x.shape[0])*x.strides[0]).astype(np.uintp)
        ypp = (y.__array_interface__['data'][0]
        + np.arange(y.shape[0])*y.strides[0]).astype(np.uintp)
        kpp = (kernel.__array_interface__['data'][0]
        + np.arange(kernel.shape[0])*kernel.strides[0]).astype(np.uintp)
        m = ctypes.c_int(x.shape[0])
        n = ctypes.c_int(x.shape[1])
        kl = ctypes.c_int(kpp.shape[0])

        # run and count time
        t = time.perf_counter()  
        self._conv2(xpp, kpp, ypp, m, n, kl)
        t = time.perf_counter() - t
        return  y, t*1000

    def hog(self, img, block=[2, 2], cell=[20,20], bins=12):
        m = img.shape[0]
        n = img.shape[1]
        cm = m // cell[0]
        cn = n // cell[1]
        bm = cm + 1 - block[0]
        bn = cn + 1 - block[1]
        features = np.zeros([bm*bn, bins])

        # solve the gradients.
        kernel = np.array([[-1,-2,-1], [0, 0, 0], [1,2,1]]).astype('float')
        gy, t1 = self.conv2(img, kernel)
        kernel = np.array([[-1,0,1], [-2, 0, 2], [-1,0,1]]).astype('float')
        gx, t2 = self.conv2(img, kernel)

        # solve the format converts.
        _gxpp = (gx.__array_interface__['data'][0]
        + np.arange(gx.shape[0])*gx.strides[0]).astype(np.uintp)
        _gypp = (gy.__array_interface__['data'][0]
        + np.arange(gy.shape[0])*gy.strides[0]).astype(np.uintp)
        _hogpp = (features.__array_interface__['data'][0]
        + np.arange(features.shape[0])*features.strides[0]).astype(np.uintp)
        _m = ctypes.c_int(img.shape[0])
        _n = ctypes.c_int(img.shape[1])
        _cm = ctypes.c_int(cell[0])
        _cn = ctypes.c_int(cell[1])
        _bm = ctypes.c_int(block[0])
        _bn = ctypes.c_int(block[1])
        _bins = ctypes.c_int(bins)

        # run and count time
        t3 = time.perf_counter()  
        self._hog(_gxpp, _gypp, _hogpp, _m, _n, _bm, _bn, _cm, _cn, _bins)
        t3 = time.perf_counter() - t3
        features = features.reshape([bm, bn, bins])
        t = t1 + t2 + t3*1000
        return features, t
    
    def plot_hog(self, features, img, bins=12, mark_ratio=0.3, show_cell_mag=False):
        img = img * (1-mark_ratio)
        cm = features.shape[0]
        cn = features.shape[1]
        cellsize_m = img.shape[0]//cm
        cellsize_n = img.shape[1]//cn
        arrow_len = min(cellsize_m, cellsize_n)/4
        mag_max = np.max(features)
        
        for i in range(cm):
            for j in range(cn):
                # angle = np.argmax(features[i, j])*np.pi/(bins-1) - np.pi/2
                # pt_c = (int(j*cellsize_n+cellsize_n/2), int(i*cellsize_m+cellsize_m/2))
                # pt_end = (int(pt_c[0] + arrow_len*np.cos(angle)), int(pt_c[1] + arrow_len*np.sin(angle)))
                # c = int(15+240*np.max(features[i, j])/mag_max)
                # img = cv.line(img, pt_c, pt_end, (c, c, c))
                for k in range(bins):
                    angle = k*np.pi/(bins-1) - np.pi/2
                    pt_c = (int(j*cellsize_n+cellsize_n/2), int(i*cellsize_m+cellsize_m/2))
                    pt_start = (int(pt_c[0] - arrow_len*np.cos(angle)), int(pt_c[1] - arrow_len*np.sin(angle)))
                    pt_end = (int(pt_c[0] + arrow_len*np.cos(angle)), int(pt_c[1] + arrow_len*np.sin(angle)))
                    c = int(255*features[i, j, k]/mag_max)
                    img = cv.line(img, pt_start, pt_end, (c, c, c))

        if show_cell_mag:
            mag = np.zeros([cm, cn])
            for i in range(cm):
                for j in range(cn):
                    mag[i, j] = np.max(features[i, j])
            mag = cv.convertScaleAbs(mag)
            cv.imshow('Normalized Magnitude of cells.', mag)
            cv.waitKey(0)

        return img

def main(image, dll_path, display=True):
    # Initilize my work instance.
    w = work(dll_name=dll_path)

    # Load and display the image.
    lena_bgr = image
    lena = cv.cvtColor(lena_bgr, cv.COLOR_BGR2GRAY)
    print("img size : %d x %d" % (lena_bgr.shape[0], lena_bgr.shape[1]))
    if display:
        cv.imshow('raw image', lena_bgr)
        cv.waitKey(0)
    lena = lena.astype('float')
    
    # Perform mean filter and display.
    k_size = 3
    kernel = np.ones([k_size, k_size])/(k_size**2)
    lena_blur, t_blur = w.conv2(lena, kernel)
    print("Conv2 blur runtime: %f ms" %(t_blur))
    if display:
        lena_blur = cv.convertScaleAbs(lena_blur)
        cv.imshow('Blurred image', lena_blur)
        cv.waitKey(0)

    # Perform SOBEL.
    kernel = np.array([[-1,-2,-1], [0, 0, 0], [1,2,1]]).astype('float')
    lena_gy, t = w.conv2(lena, kernel)
    print("Running Sobel - y, runtime %f ms" % t)
    kernel = np.array([[-1,0,1], [-2, 0, 2], [-1,0,1]]).astype('float')
    lena_gx, t = w.conv2(lena, kernel)
    print("Running Sobel - x, runtime %f ms" % t)
    # Dislay result.
    if display:
        lena_gy = cv.convertScaleAbs(lena_gy)
        lena_gx = cv.convertScaleAbs(lena_gx)
        cv.imshow('Gradient_x', lena_gy)
        cv.waitKey(0)
        cv.imshow('Gradient_y', lena_gx)
        cv.waitKey(0)

    # Perform HOG.
    cell = [20, 20]
    block = [2, 2]
    bins = 6
    hogs, t = w.hog(lena, cell=cell, block=block, bins=bins)
    print("HOG runtime %f ms" % t)
    # Display.
    if display:
        lena_bgr = np.zeros_like(lena_bgr)
        lena_bgr = w.plot_hog(hogs, lena_bgr, bins=bins)
        lena_bgr = cv.convertScaleAbs(lena_bgr)
        cv.imshow('HOGs cell:%dx%d, block:%dx%d, bins:%d'%(cell[0], cell[1], block[0], block[1], bins), lena_bgr)
        cv.waitKey(0)

    return t_blur, t

if __name__ == '__main__':
    # Set image path.
    image_path = 'test//lena.jpg'
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
    img = cv.imread(image_path)
    print("=============Parallel===================")
    main(img , 'hog_p.dll')
    print("==============Serial===================")
    main(img, 'hog_s.dll')
    test_img_length = np.linspace(0, 2000, 21)
    run_time = []

