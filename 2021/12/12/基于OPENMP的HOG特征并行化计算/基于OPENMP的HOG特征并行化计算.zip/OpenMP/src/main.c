/****************************************************************
 * Filename: main.c
 * Author  : Ikuo Pang
 * Date    : 2021-11-7
 ****************************************************************/
#include "main.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include <time.h>

/************************************
 * Function   : conv2
 * Description: Convolve 2d array and 2d array.
 * Input: 
 *  -data: 2-d matrix, mxn in size.
 *  -kernel: convolution kernel, 2-d matrix, klxkl in size.
 *  -m, -n, -kl: size of matrix.
 * Output:
 *  -out: output matrix, mxn in size.
 * Return:
 *  none.
************************************/
#define USE_THREADS 6
EXPORT void conv2(double** data, double** kernel, double** out, int m, int n, int kl){
    int kernal_rad = kl/2;

    // centre [kernal_rad:m-kernal_rad, kernal_rad:n-kernal_rad]
    // x0:x1 means x∈[x0, x1)∪x∈Z
#pragma omp parallel for num_threads(USE_THREADS)
    for(int i = kernal_rad; i < m - kernal_rad; i++){
        for(int j = kernal_rad; j < n - kernal_rad; j++){
            //Conv
            out[i][j] = 0;
            for(int k = 0; k < kl; k++){
                for(int l = 0; l < kl; l++){
                    out[i][j] += kernel[k][l] * data[i+k-kernal_rad][j+l-kernal_rad];
                }
            }
        }
    }
}

/************************************
 * Function   : HOG_normalization
 * Description: normalize HOG of a block. This function is called by
 *  function "HOG".
 * Input: 
 *  -pcells : cell of image gradients [cell_m x cell_n]x[bins].
 *  -cm, cn : number of cells. NOTE this isn't size of cell .
 *  -block_m, -block_n: block size in cells.
 *  -cell_m, cell_n: cell size in pixels.
 *  -bins : output HOG length.
 * Output:
 *  -hist : hist of gradient[cm-block_m+1]x[cn-block_n+1]..
 * Return:
 *  none.
************************************/
void HOG_normalization(double** pcells, double** hist, int block_m, int block_n, int cell_m, int cell_n, int cm, int cn, int bins){
    //number of blocks. NOTE this isn't size of block.
    int bm = cm-block_m+1;
    int bn = cm-block_m+1;

    //allocate buffer storing accumulation normalization divisors.
    double* pacc = NULL;
    pacc = (double*)malloc(sizeof(double) * bm * bn);
    if(pacc == NULL){
        perror("Can't allocate enough memory in HOG_normalization.");
        return;
    }
    memset(pacc, 0, sizeof(double) * bm * bn);

#pragma omp parallel for num_threads(USE_THREADS)
    //traverse blocks and calculate accumulations.
    for(int i = 0; i < bm; i++){
        for(int j = 0; j < bn; j++){    
            //traverse cells in a block
            for(int k = 0; k < block_m; k++){
                for(int l = 0; l < block_n; l++){
                    for(int m = 0; m < bins; m++){
                        pacc[i*bn+j] += pcells[(i+k)*cell_n + (j+l)][m]*pcells[(i+k)*cell_n + (j+l)][m];
                    }
                }
            }
            pacc[i*bn+j] = sqrt(pacc[i*bn+j]);
        }
    }

#pragma omp parallel for num_threads(USE_THREADS)
    //normalize blocks.
    for(int i = 0; i < bm; i++){
        for(int j = 0; j < bn; j++){ 
            for(int k = 0; k < bins; k++){
                hist[i*bn+j][k] = pcells[i*cn+j][k] / pacc[i*bn+j];   
            }
        }
    }

    //free 
    free(pacc);

}


/************************************
 * Function   : HOG
 * Description: calculate HOG for image.
 *  the angle of graident is from 0 to PI.
 *  0 towards right, pi/2 towards downside...
 * Input: 
 *  -gx : image gradients by axis-x, m x n.
 *  -gy : image gradients by axis-y, m x n.
 *  -m, -n: image size m x n.
 *  -block_m, -block_n: block size in cells.
 *  -cell_m, cell_n: cell size in pixels.
 *  -bins: Length of HOG features for each cell.
 * Output:
 *  -hog : HOG, 2d, [block_1_1, block_1_2, ..., block_2_1, block_2_2, ...,][HOGs...]
 * Return:
 *  none.
************************************/
EXPORT void HOG(double** gx, double** gy, double** hog, int m, int n, int block_m, int block_n, int cell_m, int cell_n, int bins){
    int _cm = m/cell_m;
    int _cn = n/cell_n;
    int _bm = _cm-1;
    int _bn = _cn-1;

    //calculate HOGS for each cell.
    //the result will be stored in a dynamic allocated array p_cells.
    double** p_cells = NULL;
    p_cells = (double**)malloc(sizeof(double*) * _cm * _cn);
    if(p_cells == NULL){
        perror("ERROR: can't malloc enough memory.\n");
        return;
    }
    for(int i = 0; i < _cm * _cn; i++){
        p_cells[i] = (double*)malloc(sizeof(double) * bins);
        if(p_cells[i] == NULL){
            perror("ERROR: can't malloc enough memory.\n");
            return;
        }
        memset(p_cells[i], 0, bins*sizeof(double));
    }

    //traverse

    double mag, angle; // gradient feature for each pixel.
    double hist_angle_space = 3.1415926/(bins-1);
    double lower_ratio;// ratio of gradient in lower index of angle. 
    int lower_idex;//subject the gradient magnitude of a pixel to lower index of angle of histogram. 

#pragma omp parallel for private(mag, angle, lower_ratio, lower_idex) num_threads(USE_THREADS)
    //traverse each cell.
    for(int i = 0; i < _cm; i++){
        for(int j = 0; j < _cn; j++){
            //traverse each pixel of a cell.
            for(int di = 0; di < cell_m; di++){
                for(int dj = 0; dj < cell_n; dj++){
                    //the pixel index in global matrix.
                    //in this part, a pixel's grad is picked up.
                    int _i = i*cell_m + di;
                    int _j = j*cell_n + dj;
                    //calculate the gradiential magnitude of a pixel.
                    mag = gx[_i][_j]*gx[_i][_j] + gy[_i][_j]*gy[_i][_j];
                    mag = sqrt(mag);
                    //calculate the gradiential angle of a pixel.
                    angle = atan2(gy[_i][_j], gx[_i][_j])-0.00001;
                    if (angle < 0){
                        angle += 3.1415926; //convert angle in to 0~pi
                    }
                    //in the following part, we subject a pixel's magnitude to a cell's histogram.
                    lower_idex = (int)(angle/hist_angle_space);
                    lower_ratio = 1-(angle-lower_idex*hist_angle_space)/hist_angle_space;
                    //ERRORs may occur due to the precision of float operation. Add this to idicate any error if somethins going wrong.
                    if(lower_idex+1 >= bins){
                        perror("ERROR: visit p_cells out of bound. Ignore and continue.");
                        printf("angle: %lf\nhist_angle_space: %lf\nlower_idex: %d\nbins: %d\n", angle, hist_angle_space, lower_idex, bins);
                        lower_idex--;
                        //return;
                    }
                    p_cells[i*_cn+j][lower_idex] += mag*lower_ratio;
                    p_cells[i*_cn+j][lower_idex+1] += mag*(1-lower_ratio);
                }
            }
        }
    }
    
    //Now normalize the HOGs of each block.
    //HOG_normalization(p_cells, hog, block_m, block_n, cell_m, cell_n, _cm, _cn, bins);
#pragma omp parallel for num_threads(USE_THREADS)
    for(int i = 0; i < _bm; i++){
        for(int j = 0; j < _bn; j++){ 
            for(int k = 0; k < bins; k++){
                //hist[i*bn+j][k] = pcells[i*cn+j][k] / pacc[i*bn+j];   
                hog[i*_bn+j][k] = p_cells[i*_cn+j][k];         
            }
        }
    }

    // free allocated memory.
    for(int i = 0; i < _cm * _cn; i++){
        free(p_cells[i]);
    }
    free(p_cells);
}

