/****************************************************************
 * Filename: main.h
 * Author  : Ikuo Pang
 * Date    : 2021-11-7
 ****************************************************************/
#ifndef __MAIN_H
#define __MAIN_H

#define BUILD_DLL

#ifdef BUILD_DLL
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __declspec(dllimport)
#endif

EXPORT void conv2(double** data, double** kernel, double** out, int m, int n, int kl);

EXPORT void HOG(double** gx, double** gy, double** hog, int m, int n, int block_m, int block_n, int cell_m, int cell_n, int bins);


#endif
