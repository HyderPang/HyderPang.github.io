from test import work, main
import numpy as np
import matplotlib.pyplot as plt

kernels = 6

# Set image path.
dll_s_path = './/hog_s.dll'
dll_p_path = './/hog_p.dll'

test_imsize = np.linspace(100, 2000, 20).astype('int')

# serial
tcost_blur_s = []
tcost_hog_s = []
for i in test_imsize:
    img = np.random.rand(i, i, 3).astype('uint8')
    t_blur, t_hog = main(img, dll_s_path, display=False)
    tcost_blur_s.append(t_blur)
    tcost_hog_s.append(t_hog)

# parallel
tcost_blur_p = []
tcost_hog_p = []
for i in test_imsize:
    img = np.random.rand(i, i, 3).astype('uint8')
    t_blur, t_hog = main(img, dll_p_path, display=False)
    tcost_blur_p.append(t_blur)
    tcost_hog_p.append(t_hog)

acc_r_blur = np.array(tcost_blur_s) / np.array(tcost_blur_p)
acc_r_hog = np.array(tcost_hog_s) / np.array(tcost_hog_p)

acc_e_blur = acc_r_blur/kernels
acc_e_hog = acc_r_hog/kernels

plt.title('Time cost (with %d kernels for parallel)' % kernels)
plt.plot(test_imsize, tcost_blur_s, marker='o', linestyle='dashed', label='Serial blur')
plt.plot(test_imsize, tcost_hog_s, marker='*', label='Serial hog')
plt.plot(test_imsize, tcost_blur_p, marker='o', linestyle='dashed', label='Parallel blur')
plt.plot(test_imsize, tcost_hog_p, marker='*', label='Parallel hog')
plt.xlabel('Image edges / pixels')
plt.ylabel('runtim / ms')
plt.legend()
plt.show()

plt.figure()
plt.title('Acceleration ratio (with %d kernels for parallel)' % kernels)
plt.plot(test_imsize, acc_r_blur, marker='o', linestyle='dashed', label='blur')
plt.plot(test_imsize, acc_r_hog, marker='*', label='hog')
plt.xlabel('Image edges / pixels')
plt.ylabel('Acceleration ratio')
plt.legend()
plt.show()

plt.figure()
plt.title('Acceleration efficiency (with %d kernels for parallel)' % kernels)
plt.plot(test_imsize, acc_e_blur, marker='o', linestyle='dashed', label='blur')
plt.plot(test_imsize, acc_e_hog, marker='*', label='hog')
plt.xlabel('Image edges / pixels')
plt.ylabel('Acceleration efficiency')
plt.legend()
plt.show()
